# Free SEO Tools (Free Version)

This is a small Node.js + Express project with three free SEO tools:
- Keyword Frequency Checker
- Meta Tag Generator
- Backlink Checker (basic link count)

Free version behavior:
- No PRO features
- Daily quota per IP (default 200 requests/day) to prevent abuse
- Burst rate limiter (30 requests/minute)

## How to run locally
1. Install Node.js (14+)
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Recommended free hosting
- Replit (import repository or upload project)
- Vercel (use a simple Node server deployment)

## Notes
- This free version is ready to deploy. If hosting on a shared platform, consider lowering `QUOTA_PER_DAY` in `server.js`.
- For production, move quotas to persistent storage (Redis) and add HTTPS + security headers.
