const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const cheerio = require('cheerio');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

// Simple in-memory daily quota per IP (free version)
const dailyQuota = {};
const QUOTA_PER_DAY = 200; // change as needed

// Reset quotas at midnight (server local time)
const now = new Date();
const msUntilMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate()+1, 0,0,5) - now;
setTimeout(function resetQuota(){
  for(const k in dailyQuota) delete dailyQuota[k];
  // schedule next reset in 24h
  setInterval(()=>{ for(const k in dailyQuota) delete dailyQuota[k]; }, 24*60*60*1000);
}, msUntilMidnight);

// Lightweight rate limiter for abusive behavior (burst protection)
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30 // limit each IP to 30 requests per minute
});
app.use(limiter);

// Helper to check free quota
function checkQuota(ip){
  if(!dailyQuota[ip]) dailyQuota[ip] = 0;
  if(dailyQuota[ip] >= QUOTA_PER_DAY) return false;
  dailyQuota[ip] += 1;
  return true;
}

// Homepage
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/views/index.html');
});

// Keyword Checker
app.get('/keyword', (req, res) => res.sendFile(__dirname + '/views/keyword.html'));
app.post('/keyword', (req, res) => {
    const ip = req.ip;
    if(!checkQuota(ip)) return res.status(429).send('Daily free quota exceeded. Try again tomorrow.');
    const text = req.body.text || '';
    const keyword = req.body.keyword || '';
    if(!keyword) return res.send('Please provide a keyword.');
    const regex = new RegExp(keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    const count = (text.match(regex) || []).length;
    res.send(`Keyword "<b>${keyword}</b>" found <b>${count}</b> times.`);
});

// Meta Tag Generator
app.get('/meta', (req, res) => res.sendFile(__dirname + '/views/meta.html'));
app.post('/meta', (req, res) => {
    const ip = req.ip;
    if(!checkQuota(ip)) return res.status(429).send('Daily free quota exceeded. Try again tomorrow.');
    const title = (req.body.title || '').slice(0, 160);
    const desc = (req.body.description || '').slice(0, 300);
    const html = `<pre>&lt;title&gt;${title}&lt;/title&gt;\n&lt;meta name=\"description\" content=\"${desc}\"&gt;</pre>`;
    res.send(html);
});

// Backlink Checker (basic, counts links in a URL)
app.get('/backlink', (req, res) => res.sendFile(__dirname + '/views/backlink.html'));
app.post('/backlink', async (req, res) => {
    const ip = req.ip;
    if(!checkQuota(ip)) return res.status(429).send('Daily free quota exceeded. Try again tomorrow.');
    const url = req.body.url || '';
    if(!url) return res.send('Please provide a valid URL (include http:// or https://).');
    try {
        const response = await axios.get(url, { timeout: 8000, headers: { 'User-Agent': 'Mozilla/5.0 (compatible; FreeSEOTools/1.0)' } });
        const $ = cheerio.load(response.data);
        const links = $('a');
        res.send(`Found <b>${links.length}</b> links on <b>${url}</b>`);
    } catch (e) {
        res.send('Error fetching the URL. Make sure it is correct and allows requests.');
    }
});

// Simple about/contact
app.get('/about', (req, res) => res.send('<h2>Free SEO Tools</h2><p>Free tools for bloggers and creators.</p>'));

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
